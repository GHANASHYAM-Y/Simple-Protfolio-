// JavaScript
let weather = {
  apiKey: "b30f885a245570783a56c082b0ed9ae8",
  fetchWeather: function (city) {
    fetch(
      "https://api.openweathermap.org/data/2.5/weather?q=" +
        city +
        "&units=metric&appid=" +
        this.apiKey
    )
      .then((response) => {
        if (!response.ok) {
          throw new Error("City not found");
        }
        return response.json();
      })
      .then((data) => this.displayWeather(data))
      .catch((error) => this.displayError(error.message));
  },
  displayWeather: function (data) {
    const { name } = data;
    const { lon, lat } = data.coord;
    const { icon, description } = data.weather[0];
    const { temp, feels_like, temp_min, temp_max, pressure, humidity } =
      data.main;
    const { speed } = data.wind;

    document.querySelector(".city").innerHTML = "Weather in " + name;
    document.querySelector(".long").innerHTML = "( " + lon + " , " + lat + " )";
    document.querySelector(".icon").src =
      "http://openweathermap.org/img/wn/" + icon + "@2x.png";
    document.querySelector(".description").innerText = description;
    document.querySelector(".temp").innerText = temp + "°C";
    document.querySelector(".feelslike").innerText =
      "Feels like: " +
      feels_like +
      "°C  ||  Max: " +
      temp_max +
      "°C  ||  Min: " +
      temp_min +
      "°C";
    document.querySelector(".pressure").innerText =
      "Pressure: " +
      pressure +
      "pa  ||  Humidity: " +
      humidity +
      "%  ||  Wind: " +
      speed +
      "km/h";
  },
  displayError: function (message) {
    document.querySelector(".city").innerText = message;
    document.querySelector(".long").innerText = "";
    document.querySelector(".icon").src = "unknown.png";
    document.querySelector(".description").innerText = "";
    document.querySelector(".temp").innerText = "- °C";
    document.querySelector(".feelslike").innerText = "";
    document.querySelector(".pressure").innerText = "";
  },
  search: function () {
    const cityInput = document.querySelector(".search-bar").value;
    if (cityInput.trim() !== "") {
      this.fetchWeather(cityInput);
    }
  },
};

document.querySelector(".search button").addEventListener("click", function () {
  weather.search();
});

document.querySelector(".search-bar").addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
    weather.search();
  }
});
