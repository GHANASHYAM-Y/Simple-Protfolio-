const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(express.static('public'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/f1.html');
});

app.post('/submit', (req, res) => {
    const { name, email, phone, location, message } = req.body;

    console.log(`Form Submitted:`);
    console.log(`Name: ${name}`);
    console.log(`Email: ${email}`);
    console.log(`Phone: ${phone}`);
    console.log(`Location: ${location}`);
    console.log(`Message: ${message}`);

    res.send('Form submitted successfully!');
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
