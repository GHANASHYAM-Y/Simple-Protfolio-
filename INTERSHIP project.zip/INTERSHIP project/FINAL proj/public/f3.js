document.querySelectorAll('nav a').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
      e.preventDefault();

      const targetId = this.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);

      if (targetElement) {
          const offset = 80;  
          const targetPosition = targetElement.offsetTop - offset;

          window.scrollTo({
              top: targetPosition,
              behavior: 'smooth'
          });
      } else {
          console.error(`Element with ID "${targetId}" not found.`);
      }
  });
});
